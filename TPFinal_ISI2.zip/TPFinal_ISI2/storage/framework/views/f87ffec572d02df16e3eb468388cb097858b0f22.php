<?php $__env->startSection('titrePage'); ?>
    Information sur le Film
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenu'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 mt-3">
                <div class="card">
                    <div class="card-horizontal">
                        <div class="card-body">
                            <h5 class="card-title">Titre : <?php echo e($film->titre); ?></h5>
                            <p class="card-text">
                            <p>Description : <?php echo e($film->description); ?></p>
                            <p>Catégorie : <?php echo e($film->categorie->libelle); ?></p>
                            <p>Année de sortie : <?php echo e($film->anneeSortie); ?></p>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Laravel\TPFinal\resources\views/afficherFilm.blade.php ENDPATH**/ ?>