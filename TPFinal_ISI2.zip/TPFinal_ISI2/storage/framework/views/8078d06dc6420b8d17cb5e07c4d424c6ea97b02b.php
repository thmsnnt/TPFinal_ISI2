<?php $__env->startSection('titrePage'); ?>
    Liste des Films
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titreItem'); ?>
    <h1>Tous les films :</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenu'); ?>

    <?php if(session()->has('info')): ?>
        <div class="card text-white bg-success mb-3" style="max-width: 18rem;">
            <div class="card-body">
                <p class="card-text"><?php echo e(session('info')); ?></p>
            </div>
        </div>
    <?php endif; ?>

    <div class="card">
        <header class="card-header">
            <p class="card-header-title">Afficher les films par catégorie : </p>
            <div class="select">
                <select onchange="window.location.href = this.value">
                    <option value="<?php echo e(route('films.index')); ?>" <?php if (! ($laCateg)): ?> selected <?php endif; ?>>Toutes les catégories</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e(route('films.categorie', $categorie->libelle)); ?>" <?php echo e($laCateg == $categorie->libelle ? 'selected' : ''); ?>><?php echo e($categorie->libelle); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </header>
        <div class="card-content">
            <div class="content">
                <table class="table is-hoverable">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Titre</th>
                        <th>Description</th>
                        <th>Année de sortie</th>
                        <th>Catégorie</th>
                    </tr>
                    </thead>
                    <?php $__currentLoopData = $lesFilms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($film->id); ?> </td>
                            <td><strong><?php echo e($film->titre); ?></strong></td>
                            <td><?php echo e($film->description); ?></td>
                            <td><?php echo e($film->anneeSortie); ?></td>
                            <td> <?php echo e($film->categorie->libelle); ?></td>
                            <td><a class="btn btn-primary" href="<?php echo e(route('films.show', $film->id)); ?>">Voir</a></td>
                            <td>
                                <form action="<?php echo e(route('films.destroy', $film->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger" type="submit">Supprimer</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Laravel\TPFinal_ISI2\resources\views/listeFilms.blade.php ENDPATH**/ ?>